<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register</title>
    <link rel="stylesheet" href="./css/style.css">
</head>
<body>
    <div class="bg">
        <header>
            <img src="./images/site/logo.png" alt="phpmotor_logo">
            <div class="myaccount" >
                <a href="?action=login-page">My Account</a>
            </div>
        </header>

        <nav>
            <?php    
                
                echo $navList;
                
            ?>
        </nav>
      
        <form method="post" action="#">

            <div class="container">
                <label>First Name</label>
                <input required  type="text" name="clientFirstname" id="clientFirstname" <?php if(isset($clientFirstname)){echo "value='$clientFirstname'";}  ?> >
                <label>Last Name</label>
                <input required type="text" name="clientLastname" id="lname" <?php if(isset($clientLastname)){echo "value='$clientLastname'";}  ?> 
                <label>Email</label>
                <input required type="email" name="clientEmail" id="email" <?php if(isset($clientEmail)){echo "value='$clientEmail'";}  ?> >
                <label>Password</label>
                <span>(Must be at least 8 characters and have 1 uppercase letter number and special character.)</span><br>
                <input required type="password" name="clientPassword" id="password" pattern="(?=^.{8,}$)(?=.*\d)(?=.*\W+)(?![.\n])(?=.*[A-Z])(?=.*[a-z]).*$">
                <button type="submit" name="submit" id="regbtn">Register</button>
                <input type="hidden" name="action" value="register">
            </div>
            

        </form>
          

            <?php    
            include 'footer.php';
            ?>
        
    </div>
   
    <script src="./js/script.js"></script>
</body>

</html>